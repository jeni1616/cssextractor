function myFunction() {
    var name = document.getElementById("name").value;

// Returns successful data submission message when the entered information is stored in database.
    var dataString = 'name1=' + name;
    if (name == '')
    {
        alert("Please Add code");
    }
    else
    {
//AJAX code to submit form.
        $(".finalresu").val("");
        $.ajax({
            type: "POST",
            url: "ajaxjs.php",
            data: dataString,
            cache: false,
            success: function(html) {
                // alert(html);
                $(".finalresu").val(html);
                $(".finalre .finalresu").select();
                //console.log(html);
            }
        });
    }
    return false;
}