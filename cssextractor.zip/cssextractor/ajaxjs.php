<?php

//Fetching Values from URL  
$name2 = $_POST['name1'];
require_once('it.php');
if (isset($_POST['name1'])) {
//Insert query 
    echo process_code($name2);   
    die();
}

?>