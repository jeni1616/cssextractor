<?php

$string = ".qodef-btn.qodef-btn-icon:not(.qodef-btn-custom-hover-bg).qodef-btn-solid .qodef-btn-text-icon {
    background-color: #9fd323;color:#ff4523;background: #000000;
}.qodef-btn.qodef-btn-solid {
    background-color: #b2dd4c;
    border: none;
    color: #fff;
    height: 52px;
    line-height: 52px;
}";
function array_addstuff($a, $i) {
    foreach ($a as &$e)
        $e = $e.$i;
    return $a;
}
function get_string_between($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}

function process_code($string){

$exparrau = explode("}", $string) ;
$myarray = array_addstuff($exparrau, "}");
$trimmed_array=array_map('trim',$myarray);
array_pop($trimmed_array);

$finalresultarray = array();
$tempstring = $flagofempty = "";

foreach ($trimmed_array as $keynew) {
	



// print "<pre>";
// print_r($trimmed_array);
// print "</pre>";

// echo "<br/>";




$selectorclass = explode("{", $keynew);

$parsed = get_string_between($keynew, '{', '}');

$display = explode(';', $parsed);

$tempstring.= $selectorclass[0].'{';

foreach ($display as $key) {
	
	$key = trim($key);
	if (0 === strpos($key, 'back')) {
	$tempstring.= $key.';';
                $flagofempty = 'havedata';
	}
	if (0 === strpos($key, 'colo')) {
	$tempstring.= $key.';';
                $flagofempty = 'havedata';
	}
	
}
$tempstring.= '}';

if($flagofempty != ""):
array_push($finalresultarray, $tempstring);
endif;
$tempstring = $flagofempty = "";
}

// print "<pre>";
// print_r($finalresultarray);
// print "</pre>";
$finalstring = "";
foreach ($finalresultarray as $key) {
	$finalstring.= $key."\n";
}
return $finalstring;
}//end process_code
?>